package com.spring.project.models;

import jakarta.persistence.*;
import lombok.Data;
import java.util.List;


@Entity
@Data
@Table(name="funcion")
public class Funcion {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private String descripcion;
	
	@ManyToMany(mappedBy = "funciones")
   List<TipoPersona> tipoPersonas;
}

