package com.spring.project.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.spring.project.repositories.TipoPersonaRepository;
import com.spring.project.models.TipoPersona;

@RestController
@RequestMapping("/tipo")
public class TipoPersonaController {

    @Autowired
    private TipoPersonaRepository tipoPersonaRepository;

    @PostMapping
    public TipoPersona crear(@RequestBody TipoPersona tipo) {
        return tipoPersonaRepository.save(tipo);
    }

    @GetMapping
    public List<TipoPersona> listar() {
        return tipoPersonaRepository.findAll();
    }

    @DeleteMapping("/{id}")
    public void eliminarTipo(@PathVariable Integer id) {
        tipoPersonaRepository.deleteById(id);
    }
}
