package com.spring.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.project.models.Personal;
import com.spring.project.repositories.PersonalRepository;

import java.util.List;

@Service
public class PersonalService {

    @Autowired
    private PersonalRepository personalRepository;

    // Crear o guardar un Personal
    public Personal crearPersonal(Personal personal) {
        return personalRepository.save(personal);
    }

    // Obtener todos los Personal
    public List<Personal> listarPersonal() {
        return personalRepository.findAll();
    }
}
