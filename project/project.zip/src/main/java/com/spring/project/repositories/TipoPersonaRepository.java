package com.spring.project.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.spring.project.models.TipoPersona;

public interface TipoPersonaRepository extends JpaRepository<TipoPersona, Integer> {

    
}
