package com.spring.project.models;

import java.util.Date;
import lombok.Data;

@Data
public class Usuario {
    private String username;
	private String name;
	private String email;
	private Date dateCreated;
	private String state;

    public Usuario() {

    }

    public Usuario(String username, String name, String email, Date dateC, String state) {
        this.username= username;
        this.name=name;
        this.email=email;
        this.dateCreated=dateC;
        this.state=state;
    }
}
