package com.spring.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.project.models.TipoPersona;
import com.spring.project.repositories.TipoPersonaRepository;

import java.util.List;

@Service
public class TipoPersonaService {

    @Autowired
    private TipoPersonaRepository tipoPersonaRepository;

    // Crear o guardar un TipoPersona
    public TipoPersona crearTipoPersona(TipoPersona tipoPersona) {
        return tipoPersonaRepository.save(tipoPersona);
    }

    // Obtener todos los TipoPersona
    public List<TipoPersona> listarTipoPersonas() {
        return tipoPersonaRepository.findAll();
    }
}
