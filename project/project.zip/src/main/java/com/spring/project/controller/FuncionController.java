package com.spring.project.controller;

import com.spring.project.models.Funcion;
import com.spring.project.services.FuncionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/funcion")
public class FuncionController {

    @Autowired
    private FuncionService funcionService;

    @PostMapping
    public Funcion crear(@RequestBody Funcion funcion) {
        return funcionService.crearFuncion(funcion);
    }

    @GetMapping
    public List<Funcion> listar() {
        return funcionService.listarFunciones();
    }
}
