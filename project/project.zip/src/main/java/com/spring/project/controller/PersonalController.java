package com.spring.project.controller;

import com.spring.project.models.Personal;
import com.spring.project.services.PersonalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/personal")
public class PersonalController {

    @Autowired
    private PersonalService personalService;

    @PostMapping
    public Personal crear(@RequestBody Personal personal) {
        return personalService.crearPersonal(personal);
    }

    @GetMapping
    public List<Personal> listar() {
        return personalService.listarPersonal();
    }
}
