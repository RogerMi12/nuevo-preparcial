package com.spring.project.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.spring.project.models.Personal;

public interface PersonalRepository extends JpaRepository<Personal, Integer> {}
