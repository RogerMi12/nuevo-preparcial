package com.spring.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.project.models.Funcion;
import com.spring.project.repositories.FuncionRepository;

import java.util.List;

@Service
public class FuncionService {

    @Autowired
    private FuncionRepository funcionRepository;

    // Crear o guardar una Funcion
    public Funcion crearFuncion(Funcion funcion) {
        return funcionRepository.save(funcion);
    }

    // Obtener todas las Funciones
    public List<Funcion> listarFunciones() {
        return funcionRepository.findAll();
    }
}
