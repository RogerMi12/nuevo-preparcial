package com.spring.project.models;

import jakarta.persistence.*;        
import lombok.Data;

@Data
@Entity
public class Personal {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private String documento;
	
	private String nombre;
	
	private String email;
	
	private String telefono;
	
	
	@ManyToOne
	@JoinColumn(name = "tipo_personal_id")
	private TipoPersona tipoPersona;
}
